# LED SPIN V2 — Cahier des charges UX

## 1. Principes
- Portrait verrouillé.
- Machine et zones principales stables : aucun déplacement pendant le spin.
- Touch targets >= 44 px.
- États réseau et erreurs explicites.
- Jetons exclusivement virtuels.
- Résultat calculé côté serveur et enregistré avant l'animation.
- L'animation ne décide jamais du résultat.

## 2. Parcours
Accueil → sélection des animaux → mise → START → spin → résultat → historique.

Menu secondaire : Règles / Paramètres / Commentaires / À propos.

## 3. Sélection
Chaque animal est une carte. Clic :
- sélection/désélection ;
- contour lumineux ;
- coche ;
- compteur de sélection.

Actions : Tous / Aucun.

Un spin exige au moins un animal sélectionné.

## 4. Moteur de gains
Chaque animal possède :
- `weight` : poids du tirage ;
- `multiplier` : multiplicateur ;
- `tier` : catégorie de gain.

Le serveur choisit un animal uniquement parmi les animaux sélectionnés.

Bonus de sélection :
- 1 animal : ×1,00
- 2 animaux : ×1,10
- 3 animaux : ×1,25
- 4 animaux : ×1,40
- 5+ animaux : ×1,50

Gain = floor(mise × multiplicateur × bonus).

Le coût de la partie est la mise. Si le gain vaut 0, aucun jeton n'est rendu. Si le gain est positif, il est crédité après validation serveur.

## 5. Table initiale
- Buffle : ×1,20, poids 24
- Zèbre : ×1,50, poids 20
- Lion : ×2,00, poids 16
- Éléphant : ×3,00, poids 13
- Girafe : ×2,50, poids 10
- Crocodile : ×3,50, poids 7
- Léopard : ×5,00, poids 4
- Rhinocéros : ×8,00, poids 2
- Aigle : ×12,00, poids 1
- Tigre : ×6,00, poids 1
- Hippopotame : ×4,00, poids 1
- Serpent : ×2,00, poids 1

Les poids sont relatifs et recalculés uniquement sur les animaux sélectionnés.

## 6. UX du résultat
- PERDU : animation courte, sans secousse de toute la page.
- GAIN : lumière douce.
- GROS GAIN : animation plus forte.
- JACKPOT : animation spéciale, sans déplacement de la machine.

## 7. Paramètres
Son, musique, vibration, intensité des animations, thème, préférence de réduction des animations, verrouillage portrait, réinitialisation.

## 8. Commentaires
Formulaire : type, note, message. Le serveur envoie le message à `yvesdjon59@gmail.com` via SMTP configuré côté serveur. Aucun secret SMTP dans l'APK.

## 9. Performance
Images SVG/Vectorielles ou WebP haute résolution. Préchargement. Animations Reanimated. Éviter les recalculs à chaque frame.

## 10. Sécurité
Le résultat, le solde et l'historique sont serveur-authoritative. Le client ne peut pas choisir le résultat. Toutes les données de jeu sont validées côté serveur.

# Moteur de gains

Le résultat est tiré parmi les animaux sélectionnés.

Pour chaque animal :
`weight` = poids relatif du tirage.
`multiplier` = multiplicateur brut.

Le bonus de sélection est :
1 animal 1.00
2 animaux 1.10
3 animaux 1.25
4 animaux 1.40
5+ animaux 1.50

Exemple :
mise = 100
3 animaux sélectionnés
Éléphant ×3
bonus = 1.25

gain = floor(100 × 3 × 1.25) = 375 jetons.

Le serveur débite 100 puis crédite 375, donc le solde net du tour est +275.

Cette logique est volontairement explicite : elle peut être auditée et modifiée depuis la configuration administrateur.

# LED SPIN V2 — expérience complète

Projet de refonte de LED SPIN : interface mobile élégante, machine LED fixe, sélection multiple d'animaux, gains transparents, historique, paramètres, règles et formulaire de commentaires.

## Structure
- `app/` : application Expo React Native
- `server/` : API Node/Express + SQLite pour le prototype
- `docs/` : cahier des charges et modèle de gains

## Lancer l'API
```bash
cd server
npm install
cp .env.example .env
npm start
```

## Lancer l'application
```bash
cd app
npm install
npx expo start
```

Dans `app/src/config.js`, définir l'URL de l'API correspondant au téléphone/PC.

## Important
Les jetons sont virtuels et sans valeur monétaire. Le moteur de gain est transparent et configurable. Pour une production publique : PostgreSQL, authentification robuste, rate limiting, sauvegardes et observabilité.

Les animaux utilisent par défaut des SVG Twemoji distants : ils restent nets à toutes les tailles. Pour une version totalement hors ligne, télécharger des assets licenciés et les placer dans `app/assets/animals/`.

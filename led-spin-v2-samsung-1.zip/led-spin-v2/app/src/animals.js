export const ANIMALS = [
 {id:"lion",name:"Lion",emoji:"🦁",multiplier:2,weight:16,color:"#F6B73C",tier:"GAIN"},
 {id:"elephant",name:"Éléphant",emoji:"🐘",multiplier:3,weight:13,color:"#9AA4B2",tier:"GROS GAIN"},
 {id:"tiger",name:"Tigre",emoji:"🐯",multiplier:6,weight:1,color:"#F58A2A",tier:"TRÈS RARE"},
 {id:"crocodile",name:"Crocodile",emoji:"🐊",multiplier:3.5,weight:7,color:"#54B46A",tier:"GROS GAIN"},
 {id:"giraffe",name:"Girafe",emoji:"🦒",multiplier:2.5,weight:10,color:"#E9B84B",tier:"GAIN"},
 {id:"zebra",name:"Zèbre",emoji:"🦓",multiplier:1.5,weight:20,color:"#E9EDF4",tier:"PETIT GAIN"},
 {id:"rhino",name:"Rhinocéros",emoji:"🦏",multiplier:8,weight:2,color:"#87909E",tier:"JACKPOT"},
 {id:"hippo",name:"Hippopotame",emoji:"🦛",multiplier:4,weight:1,color:"#9A819B",tier:"GROS GAIN"},
 {id:"leopard",name:"Léopard",emoji:"🐆",multiplier:5,weight:4,color:"#D99A35",tier:"TRÈS RARE"},
 {id:"buffalo",name:"Buffle",emoji:"🐃",multiplier:1.2,weight:24,color:"#73563D",tier:"PETIT GAIN"},
 {id:"snake",name:"Serpent",emoji:"🐍",multiplier:2,weight:1,color:"#67B85A",tier:"GAIN"},
 {id:"eagle",name:"Aigle",emoji:"🦅",multiplier:12,weight:1,color:"#C9D0D8",tier:"JACKPOT"}
];
export const BETS=[10,20,50,100,200,500];
export const SELECTION_BONUS=n=>n<=1?1:n===2?1.1:n===3?1.25:n===4?1.4:1.5;

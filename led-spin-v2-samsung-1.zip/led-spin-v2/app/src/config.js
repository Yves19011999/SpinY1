export const API_URL = "http://192.168.1.100:3000";
export const CONTACT_EMAIL = "yvesdjon59@gmail.com";

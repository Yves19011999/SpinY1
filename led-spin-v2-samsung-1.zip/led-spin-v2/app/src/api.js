import {API_URL} from "./config";
export async function api(path, options={}){
 const res=await fetch(API_URL+path,{headers:{"Content-Type":"application/json",...(options.headers||{})},...options});
 const data=await res.json().catch(()=>({}));
 if(!res.ok) throw new Error(data.error||"Erreur réseau");
 return data;
}
